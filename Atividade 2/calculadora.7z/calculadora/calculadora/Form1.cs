﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            txtnum.Clear();
            txtnum2.Clear();
            txtres.Clear();

            txtnum.Focus();
            resultado = 0;
        }

        private void BtnMultiplicar_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtres.Text = resultado.ToString();
        }

        private void Txtnum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum2.Text, out numero2))
            {
                MessageBox.Show("Número Inválido");
                txtnum2.Focus();
            }
        }

        private void BtnMais_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtres.Text = resultado.ToString();
        }

        private void BtnMenos_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtres.Text = resultado.ToString();
        }

        private void BtnDividir_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por 0.", "Erro",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtnum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtres.Text = resultado.ToString();
            }
        }

        private void Txtres_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnSair_Click(object sender, EventArgs e)
        {

            if ( MessageBox.Show("Você deseja mesmo sair?",
            "saída", MessageBoxButtons.YesNo,
            MessageBoxIcon.Question) ==
            DialogResult.Yes)
            {
                Close();
            }
            

            
           
           
        }

        private void Txtnum_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum.Text, out numero1))
            {
                MessageBox.Show("Número Inválido");
                txtnum.Focus();
            }
        }
    }
}
