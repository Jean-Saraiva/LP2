﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
             
        private void Button1_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[8, 3];
            string aux = "";
            double media = 0;
            double pTotal;
            double reserv = 0;
        

            for (int loja = 0; loja < 3; loja++)
            {
                for (int computador = 0; computador < 8; computador++)
                {
                    aux = Interaction.InputBox($"Digite o preço do computador número " + computador);

                    if (!double.TryParse(aux, out vetor[computador, loja]))
                    {
                        MessageBox.Show("Número inválido.");
                        computador--;
                    }
                    else
                    {
                        listBox1.Items.Add("Computador número " + (computador+1) + " Na Loja: " + (loja+1)  + " R$ " + vetor[computador, loja]);
                        media += vetor[computador, loja];
                        reserv += vetor[computador, loja];
                    }
                    
                }
                double mediaLoja;
                mediaLoja = reserv / 8;
                listBox1.Items.Add("Média da Loja " + (loja+1) + " = R$ " + mediaLoja);
                reserv = 0;
                
                    
            }

            listBox1.Items.Add("Preço Total: " + "R$ " + media);
            pTotal = media / 8;
            listBox1.Items.Add("Média final dos preços: " + "R$ " + pTotal);
        }
    }
}
